# VanQuang-FF-Test

Website demo tĩnh để thử nghiệm trên Android và GitHub Pages.

## Có gì?
- Giao diện tối, responsive cho điện thoại.
- Mô hình nhân vật demo dựng bằng Three.js (không phải model chính thức của Free Fire).
- Xoay nhân vật bằng thao tác kéo, nút xoay trái/phải.
- Lựa chọn tóc, mặt nạ, áo, quần, giày, gói đồ, dáng đứng và hành động.
- Phối ngẫu nhiên, đặt lại, lưu trong trình duyệt.
- Xuất/nhập cấu hình phối đồ JSON.

## Chạy trên Android
Mở `index.html` trong Acode hoặc tải cả thư mục lên GitHub Pages. Phần xem trước 3D dùng Three.js từ CDN nên cần internet.

## GitHub Pages
1. Tạo repository mới tên `VanQuang-FF-Test`.
2. Upload `index.html` lên thư mục gốc của repository.
3. Mở Settings > Pages.
4. Ở Build and deployment, chọn Deploy from a branch.
5. Chọn branch `main`, folder `/(root)`, bấm Save.
6. Chờ workflow hoàn tất. Địa chỉ thường là:
   https://TEN-TAI-KHOAN.github.io/VanQuang-FF-Test/

## Lưu ý
JSON được xuất là file cấu hình phối đồ của website, không phải gói mod cài trực tiếp vào Free Fire. Nhân vật hiện tại là hình khối demo tự dựng.
